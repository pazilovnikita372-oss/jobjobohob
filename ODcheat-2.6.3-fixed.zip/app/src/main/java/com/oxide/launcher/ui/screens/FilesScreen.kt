package com.oxide.launcher.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class OxideFile(
    val name: String,
    val uri: Uri,
    val sizeBytes: Long,
    val modified: Long
)

@Composable
fun FilesScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val context = LocalContext.current
    var importedFiles by remember { mutableStateOf<List<OxideFile>>(emptyList()) }
    var isImporting by remember { mutableStateOf(false) }
    var pendingDeleteFile by remember { mutableStateOf<OxideFile?>(null) }

    // File picker launcher
    val pickFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        isImporting = true
        val newFiles = uris.mapNotNull { uri ->
            try {
                val cr = context.contentResolver
                val cursor = cr.query(uri, null, null, null, null)
                var name = "file_${System.currentTimeMillis()}"
                var size = 0L
                var modified = System.currentTimeMillis()
                cursor?.use {
                    val ni = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val si = it.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (it.moveToFirst()) {
                        if (ni >= 0) name = it.getString(ni)
                        if (si >= 0) size = it.getLong(si)
                    }
                }
                OxideFile(name = name, uri = uri, sizeBytes = size, modified = modified)
            } catch (e: Exception) {
                null
            }
        }
        importedFiles = importedFiles + newFiles
        isImporting = false
        if (newFiles.isNotEmpty()) viewModel.showSnack("Импортировано: ${newFiles.size} файл(ов)")
    }

    // Export launcher
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        uri?.let {
            viewModel.showSnack("Экспорт в ${uri.lastPathSegment} выполнен")
        }
    }

    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "ФАЙЛЫ", onBack = { navController.popBackStack() })
            NeonDivider()

            // Action buttons
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OxideButton(
                    text    = "Выбрать файлы",
                    icon    = Icons.Default.Add,
                    color   = OxideNeonBlue,
                    modifier = Modifier.weight(1f)
                ) { pickFileLauncher.launch(arrayOf("*/*")) }

                OxideButton(
                    text    = "Экспорт",
                    icon    = Icons.Default.CloudUpload,
                    color   = OxideNeonPurple,
                    modifier = Modifier.weight(1f)
                ) { exportLauncher.launch("oxide_backup_${System.currentTimeMillis()}.zip") }
            }

            if (isImporting) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    color    = OxideNeonBlue
                )
            }

            // File list
            if (importedFiles.isEmpty()) {
                EmptyState(
                    icon    = Icons.Default.FolderOpen,
                    message = "Нет импортированных файлов.\nНажмите «Выбрать файлы»"
                )
            } else {
                LazyColumn(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Spacer(Modifier.height(4.dp)) }
                    items(importedFiles, key = { it.uri.toString() }) { file ->
                        FileItemCard(
                            file    = file,
                            onShare = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "*/*"
                                    putExtra(Intent.EXTRA_STREAM, file.uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Поделиться"))
                            },
                            onDelete = { pendingDeleteFile = file }
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }

        // Confirm delete dialog
        pendingDeleteFile?.let { file ->
            AlertDialog(
                onDismissRequest = { pendingDeleteFile = null },
                title   = { Text("Удалить файл?", color = OxideTextPrimary) },
                text    = { Text("«${file.name}» будет удалён из ODcheat.", color = OxideTextSecond) },
                confirmButton = {
                    TextButton(onClick = {
                        importedFiles = importedFiles.filter { it.uri != file.uri }
                        pendingDeleteFile = null
                        viewModel.showSnack("Файл удалён")
                    }) { Text("Удалить", color = OxideError) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeleteFile = null }) {
                        Text("Отмена", color = OxideTextSecond)
                    }
                },
                containerColor = OxideNavyBlue
            )
        }
    }
}

@Composable
private fun FileItemCard(
    file: OxideFile,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val ext = file.name.substringAfterLast('.', "?").lowercase()
    val (icon, color) = when (ext) {
        "jpg", "jpeg", "png", "webp", "gif" -> Icons.Default.Image to OxideNeonPurple
        "mp4", "mkv", "avi"                 -> Icons.Default.VideoFile to OxideNeonPink
        "mp3", "flac", "ogg"                -> Icons.Default.AudioFile to OxideNeonCyan
        "pdf", "doc", "docx", "txt"         -> Icons.Default.Description to OxideNeonBlue
        "apk"                               -> Icons.Default.Android to OxideNeonViolet
        else                                -> Icons.Default.InsertDriveFile to OxideTextSecond
    }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(file.name, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    color = OxideTextPrimary, maxLines = 1)
                Text(
                    formatSize(file.sizeBytes),
                    fontSize = 11.sp, color = OxideTextSecond
                )
            }
            IconButton(onClick = onShare) {
                Icon(Icons.Default.Share, contentDescription = "Поделиться",
                    tint = OxideNeonBlue, modifier = Modifier.size(20.dp))
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Удалить",
                    tint = OxideError, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = OxideTextSecond.copy(0.4f),
                modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(16.dp))
            Text(message, fontSize = 14.sp, color = OxideTextSecond.copy(0.6f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
fun OxideButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(0.4f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = text, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes < 1024         -> "$bytes B"
    bytes < 1024 * 1024  -> "${bytes / 1024} KB"
    else                 -> "${bytes / 1024 / 1024} MB"
}
