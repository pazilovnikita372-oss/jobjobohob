package com.oxide.launcher.ui.screens

import androidx.compose.animation.core.*
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.oxide.launcher.overlay.OxideOverlayService
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.R
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.navigation.Screen
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel

/** Пакет установленной игры OXIDE: Survival Island. Запускается только по нажатию пользователя. */
const val OXIDE_GAME_PACKAGE = "com.catsbit.oxidesurvivalisland"

@Composable
fun HomeScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val t = rememberInfiniteTransition(label = "home")
    val logoScale by t.animateFloat(
        initialValue = 1f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "logoScale"
    )
    val glowAlpha by t.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "glow"
    )
    // Медленный дрейф фона: плавно туда-обратно по двум осям с разным периодом
    val driftX by t.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "driftX"
    )
    val driftY by t.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(34000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "driftY"
    )
    val breathe by t.animateFloat(
        initialValue = 1.12f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(40000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "breathe"
    )

    OxideBackground {
        Image(
            painter = painterResource(R.drawable.oxide_space_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = breathe
                    scaleY = breathe
                    translationX = driftX * size.width * 0.04f
                    translationY = driftY * size.height * 0.025f
                }
        )
        Box(
            Modifier
                .size(320.dp)
                .align(Alignment.TopCenter)
                .offset(y = (-60).dp)
                .background(
                    Brush.radialGradient(listOf(OxideNeonPurple.copy(alpha = 0.18f), Color.Transparent)),
                    shape = CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(0.5f))

            Box(modifier = Modifier.scale(logoScale), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .background(
                            Brush.radialGradient(
                                listOf(OxideNeonBlue.copy(alpha = glowAlpha * 0.4f), Color.Transparent)
                            ),
                            shape = CircleShape
                        )
                )
                Image(
                    painter = painterResource(R.drawable.odcheat_logo),
                    contentDescription = "OXIDE",
                    modifier = Modifier.size(96.dp).clip(RoundedCornerShape(22.dp))
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                text = "ODcheat", fontSize = 46.sp, fontWeight = FontWeight.Black,
                letterSpacing = 8.sp, color = OxideTextPrimary
            )
            Text(
                text = "GAME  •  COMPANION  •  MORE", fontSize = 11.sp,
                letterSpacing = 3.sp, color = OxideTextSecond
            )

            Spacer(Modifier.weight(1f))

            uiState.profiles.firstOrNull { it.isCurrent }?.let { current ->
                Box(Modifier.padding(bottom = 12.dp)) { OxideBadge("● ${current.name}", OxideNeonCyan) }
            }

            // Сетка 2x2 с картинками-иконками: текст больше не рвётся по буквам
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ImageActionCard(R.drawable.ic_fn_files, "Файлы", Modifier.weight(1f)) {
                    navController.navigate(Screen.Files.route)
                }
                ImageActionCard(R.drawable.ic_fn_apps, "Приложения", Modifier.weight(1f)) {
                    navController.navigate(Screen.Apps.route)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ImageActionCard(R.drawable.ic_fn_profiles, "Профили", Modifier.weight(1f)) {
                    navController.navigate(Screen.Profiles.route)
                }
                ImageActionCard(R.drawable.ic_fn_skins, "Скины", Modifier.weight(1f)) {
                    navController.navigate(Screen.Skins.route)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ImageActionCard(R.drawable.ic_fn_game, "Запустить игру", Modifier.weight(1f)) {
                    viewModel.launchApp(OXIDE_GAME_PACKAGE, context)
                }
                ImageActionCard(R.drawable.ic_fn_settings, "Настройки", Modifier.weight(1f)) {
                    navController.navigate(Screen.Settings.route)
                }
            }
            Spacer(Modifier.height(9.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = {
                    if (Settings.canDrawOverlays(context)) {
                        context.startService(Intent(context, OxideOverlayService::class.java))
                        Toast.makeText(context, "Плавающее меню ODcheat включено", Toast.LENGTH_SHORT).show()
                    } else {
                        val permissionIntent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(permissionIntent)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = OxideNeonCyan)
            ) {
                Text("Ø  ОТКРЫТЬ ПЛАВАЮЩЕЕ MEGA GUI", fontSize = 11.sp, letterSpacing = 1.sp)
            }

            Spacer(Modifier.height(14.dp))
            NeonDivider()
            Spacer(Modifier.height(10.dp))
            Text(
                text = "O D C H E A T  •  GAME COMPANION",
                fontSize = 9.sp, letterSpacing = 2.sp,
                color = OxideTextSecond.copy(alpha = 0.7f), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
        }

        uiState.snackMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = { TextButton(onClick = { viewModel.clearSnack() }) { Text("OK") } }
            ) { Text(msg) }
        }
    }
}
