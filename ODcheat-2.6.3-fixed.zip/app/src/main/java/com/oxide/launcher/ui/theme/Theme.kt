package com.oxide.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OxideDarkColors = darkColorScheme(
    primary          = OxideNeonBlue,
    onPrimary        = OxideDeepBlack,
    secondary        = OxideNeonPurple,
    onSecondary      = OxideTextPrimary,
    tertiary         = OxideNeonPink,
    background       = OxideDeepBlack,
    surface          = OxideSpaceBlue,
    onBackground     = OxideTextPrimary,
    onSurface        = OxideTextPrimary,
    error            = OxideError,
    onError          = OxideTextPrimary,
    outline          = OxideGlassBorder,
)

@Composable
fun OxideTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = OxideDarkColors,
        typography  = OxideTypography,
        content     = content
    )
}
