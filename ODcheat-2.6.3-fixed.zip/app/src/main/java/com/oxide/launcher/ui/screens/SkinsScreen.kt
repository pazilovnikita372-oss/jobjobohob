package com.oxide.launcher.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel

data class OxideSkin(
    val id: String,
    val name: String,
    val description: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val isPremium: Boolean = false,
    val imageRes: Int? = null
)

private val builtinSkins = listOf(
    OxideSkin("default",  "Nebula Blue",    "Классический неоновый стиль", OxideNeonBlue,   OxideNeonPurple),
    OxideSkin("violet",   "Deep Violet",    "Глубокий фиолетовый космос",  OxideNeonViolet, OxideNeonPink),
    OxideSkin("cyber",    "Cyber Cyan",     "Яркий киберпанк",             OxideNeonCyan,   OxideNeonBlue),
    OxideSkin("crimson",  "Crimson Void",   "Тёмно-красный вакуум",        Color(0xFFFF2244), OxideNeonPurple),
    OxideSkin("gold",     "Solar Gold",     "Золотой солнечный ветер",     Color(0xFFFFAA00), Color(0xFFFF6600)),
    OxideSkin("mono",     "Ghost White",    "Минималистичный белый",       Color(0xCCFFFFFF), Color(0x88FFFFFF), false),
    OxideSkin("matrix",   "Matrix Green",   "Зелёный цифровой дождь",      Color(0xFF00FF44), Color(0xFF005522), true),
    OxideSkin("plasma",   "Plasma Storm",   "Розово-фиолетовая плазма",    OxideNeonPink,   OxideNeonViolet,  true),
    OxideSkin("warrior_crimson", "Crimson Vanguard", "Красный тяжёлый комплект", Color(0xFFFF513D), Color(0xFF761D35), imageRes = com.oxide.launcher.R.drawable.skin_warrior_crimson),
    OxideSkin("rogue_ruby", "Ruby Shadow", "Тёмный красный разведчик", Color(0xFFB8324C), Color(0xFF32182C), imageRes = com.oxide.launcher.R.drawable.skin_rogue_ruby),
    OxideSkin("dragon_silver", "Silver Dragon", "Серебряная драконья броня", Color(0xFFD9E6FF), Color(0xFF687BA8), imageRes = com.oxide.launcher.R.drawable.skin_dragon_silver),
    OxideSkin("frost_guardian", "Frost Guardian", "Ледяной защитник", Color(0xFF55CFFF), Color(0xFF244B9A), imageRes = com.oxide.launcher.R.drawable.skin_frost_guardian),
)

@Composable
fun SkinsScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedSkinId = uiState.settings.selectedSkinId

    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "СКИНЫ & ОФОРМЛЕНИЕ", onBack = { navController.popBackStack() })
            NeonDivider()

            Text("Изображения доступны как образы и превью внутри приложения. Они не меняют модель персонажа в самой игре.", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 11.sp, color = OxideTextSecond)

            Text(
                "Выберите образ для галереи ODcheat",
                modifier  = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                fontSize  = 12.sp,
                color     = OxideTextSecond
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement   = Arrangement.spacedBy(10.dp)
            ) {
                items(builtinSkins, key = { it.id }) { skin ->
                    SkinCard(
                        skin       = skin,
                        isSelected = skin.id == selectedSkinId,
                        onSelect   = {
                            if (!skin.isPremium) viewModel.selectSkin(skin.id)
                            else viewModel.showSnack("Этот стиль пока закрыт")
                        }
                    )
                }
                item {
                    ImportSkinCard(onImport = {
                        viewModel.showSnack("Импорт пользовательских изображений добавим отдельно")
                    })
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }

        uiState.snackMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action   = { TextButton(onClick = { viewModel.clearSnack() }) { Text("OK") } }
            ) { Text(msg) }
        }
    }
}

@Composable
private fun SkinCard(skin: OxideSkin, isSelected: Boolean, onSelect: () -> Unit) {
    val borderColor = if (isSelected) skin.primaryColor else OxideGlassBorder
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(174.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        skin.secondaryColor.copy(alpha = 0.3f),
                        skin.primaryColor.copy(alpha = 0.15f)
                    )
                )
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onSelect() }
    ) {
        val previewRes = skin.imageRes ?: when (skin.id) {
            "violet" -> com.oxide.launcher.R.drawable.skin_violet
            "cyber" -> com.oxide.launcher.R.drawable.skin_cyber
            "crimson" -> com.oxide.launcher.R.drawable.skin_crimson
            "gold" -> com.oxide.launcher.R.drawable.skin_gold
            "mono" -> com.oxide.launcher.R.drawable.skin_mono
            "matrix" -> com.oxide.launcher.R.drawable.skin_matrix
            "plasma" -> com.oxide.launcher.R.drawable.skin_plasma
            else -> com.oxide.launcher.R.drawable.skin_default
        }
        Image(
            painter = painterResource(previewRes),
            contentDescription = skin.name,
            contentScale = if (skin.imageRes != null) ContentScale.Fit else ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC050810)))
            )
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(80.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            skin.primaryColor.copy(0.5f),
                            skin.secondaryColor.copy(0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Selected checkmark
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(22.dp)
                    .background(skin.primaryColor, RoundedCornerShape(50))
            ) {
                Icon(Icons.Default.Check, contentDescription = null,
                    tint = OxideDeepBlack, modifier = Modifier.size(14.dp).align(Alignment.Center))
            }
        }

        // Premium badge
        if (skin.isPremium) {
            OxideBadge(
                text  = "PREMIUM",
                color = Color(0xFFFFAA00)
            )
        }

        // Name & description
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
        ) {
            Text(skin.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OxideTextPrimary)
            Text(skin.description, fontSize = 10.sp, color = OxideTextSecond, maxLines = 1)
        }
    }
}

@Composable
private fun ImportSkinCard(onImport: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(174.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(OxideGlassWhite)
            .border(1.dp, OxideGlassBorder, RoundedCornerShape(16.dp))
            .clickable { onImport() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null,
                tint = OxideTextSecond, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(8.dp))
            Text("Импорт изображения", fontSize = 12.sp, color = OxideTextSecond)
        }
    }
}
