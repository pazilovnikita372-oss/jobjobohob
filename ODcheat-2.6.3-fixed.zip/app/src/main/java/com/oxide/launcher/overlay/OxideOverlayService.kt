package com.oxide.launcher.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.content.Context

/**
 * Плавающий интерфейс OXIDE Mega GUI.
 *
 * Это companion overlay: он управляет только собственными настройками интерфейса
 * и тренировочными параметрами. Android не предоставляет этому сервису доступ
 * к памяти, рендеру или сетевым данным сторонней игры.
 */
class OxideOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("oxide_mega_gui", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) stopSelf()
        return START_STICKY
    }

    private fun params(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity; x = 24; y = 180 }

    private fun bg(color: Int, radius: Float, stroke: Int = Color.TRANSPARENT) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (stroke != Color.TRANSPARENT) setStroke(2, stroke)
        }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "Ø"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = bg(Color.rgb(93, 62, 220), 100f, Color.rgb(70, 220, 255))
            elevation = 12f
        }
        val lp = params(dp(54), dp(54)).apply {
            x = prefs.getInt("bubble_x", 24); y = prefs.getInt("bubble_y", 180)
        }
        b.setOnTouchListener(DragTouchListener(lp) { openPanel() })
        wm.addView(b, lp)
        bubble = b; bubbleParams = lp
    }

    private fun openPanel() {
        if (panel != null) { closePanel(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(Color.rgb(13, 15, 31), 28f, Color.rgb(67, 91, 190))
            elevation = 18f
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "ODcheat  /  MEGA GUI"; textSize = 17f
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 20f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(dp(16), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(close)
        root.addView(header)
        addLabel(root, "COMPANION CONTROL CENTER")
        addSection(root, "VISUAL / ПРЕДПРОСМОТР")
        addToggle(root, "ESP Preview", "Локальная демонстрация интерфейса", "esp_preview")
        addToggle(root, "Player markers", "Макет маркеров без чтения игры", "markers")
        addToggle(root, "Distance labels", "Тестовая индикация расстояния", "distance")
        addSection(root, "PLAYER / ПЕРСОНАЛИЗАЦИЯ")
        addToggle(root, "Skin preview", "Предпросмотр оформления в меню", "skin_preview")
        addSection(root, "SKIN GALLERY / ГАЛЕРЕЯ")
        addSkinGallery(root)
        addSection(root, "HUD WORKSHOP / РЕДАКТОР HUD")
        addToggle(root, "HUD editor", "Настройка положения элементов GUI", "hud_editor")
        addToggle(root, "Crosshair preview", "Прицел только внутри окна companion", "crosshair_preview")
        addToggle(root, "Mini status panel", "Локальная панель статуса приложения", "status_panel")
        addToggle(root, "FPS counter demo", "Демонстрационный счётчик, не FPS игры", "fps_demo")
        addToggle(root, "Compact mode", "Уменьшенный размер панели", "compact_mode")
        addSection(root, "TRAINING / ТРЕНИРОВКА")
        addSlider(root, "Sensitivity", "sensitivity", 1, 100, 50)
        addSlider(root, "FOV preview", "fov", 60, 120, 90)
        addSlider(root, "Overlay opacity", "overlay_opacity", 35, 100, 94)
        addSlider(root, "Panel scale", "panel_scale", 80, 120, 100)
        addSection(root, "SYSTEM")
        addToggle(root, "Animations", "Анимации плавающего меню", "animations", true)
        addToggle(root, "Remember panel state", "Сохранять локальные переключатели", "remember_state", true)
        addToggle(root, "Show helper labels", "Показывать пояснения к настройкам", "helper_labels", true)
        val note = TextView(this).apply {
            text = "Важно: это отдельное overlay-меню. Игровые ESP/Aim/skin эффекты не применяются к OXIDE без поддержки самой игры."
            textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, dp(10), 0, 0)
        }
        root.addView(note)
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        val lp = params(dp(310), dp(500)).apply { x = dp(12); y = dp(72) }
        // Перетаскивание панели выполняется за верхнюю строку, не блокируя прокрутку.
        header.setOnTouchListener(DragTouchListener(lp, {}, scroll))
        wm.addView(scroll, lp)
        panel = scroll; panelParams = lp
    }

    private fun addSection(root: LinearLayout, text: String) {
        val v = TextView(this).apply {
            this.text = text; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(93, 205, 255)); setPadding(0, dp(14), 0, dp(5))
        }
        root.addView(v)
        val imageName = when {
            text.contains("VISUAL") -> "mega_cat_visuals"
            text.contains("PLAYER") -> "mega_cat_player"
            text.contains("TRAINING") -> "mega_cat_training"
            text.contains("SYSTEM") -> "mega_cat_system"
            text.contains("SKIN GALLERY") -> "mega_cat_gallery"
            text.contains("HUD WORKSHOP") -> "mega_cat_hud"
            else -> null
        }
        if (imageName != null) {
            val imageId = resources.getIdentifier(imageName, "drawable", packageName)
            if (imageId != 0) {
                val banner = ImageView(this).apply {
                    setImageResource(imageId)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = bg(Color.rgb(20, 24, 48), dp(14).toFloat())
                    clipToOutline = true
                }
                root.addView(banner, LinearLayout.LayoutParams(-1, dp(86)).apply {
                    bottomMargin = dp(5)
                })
            }
        }
    }

    private fun addLabel(root: LinearLayout, text: String) {
        val v = TextView(this).apply {
            this.text = text; textSize = 9f; setTextColor(Color.GRAY)
            setPadding(0, 0, 0, dp(5))
        }
        root.addView(v)
    }

    private fun addToggle(root: LinearLayout, name: String, hint: String, key: String, default: Boolean = false) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply {
            text = name; textSize = 13f; setTextColor(Color.WHITE)
        })
        labels.addView(TextView(this).apply {
            text = hint; textSize = 9f; setTextColor(Color.LTGRAY)
        })
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(sw)
        root.addView(row)
    }

    private fun addSkinGallery(root: LinearLayout) {
        val names = listOf("Nebula", "Phantom", "Cyber", "Crimson", "Gold", "Arctic", "Synth", "Abyss", "Ember", "Toxic", "Chrome", "Pulse")
        val gallery = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val selected = prefs.getInt("selected_avatar_theme", 0)
        names.forEachIndexed { index, name ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(5), dp(5), dp(5))
                background = bg(
                    if (index == selected) Color.rgb(38, 45, 91) else Color.rgb(23, 26, 46),
                    14f,
                    if (index == selected) Color.rgb(75, 210, 255) else Color.rgb(55, 61, 92)
                )
            }
            val image = ImageView(this).apply {
                val resId = resources.getIdentifier("mega_skin_${(index + 1).toString().padStart(2, '0')}", "drawable", packageName)
                if (resId != 0) setImageResource(resId)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            card.addView(image, LinearLayout.LayoutParams(dp(76), dp(104)))
            val label = TextView(this).apply {
                text = name; textSize = 9f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(0, dp(5), 0, 0)
            }
            card.addView(label)
            card.setOnClickListener {
                prefs.edit().putInt("selected_avatar_theme", index).apply()
                Toast.makeText(this, "$name выбран для предпросмотра", Toast.LENGTH_SHORT).show()
                closePanel()
                openPanel()
            }
            strip.addView(card, LinearLayout.LayoutParams(dp(92), dp(145)).apply { marginEnd = dp(8) })
        }
        gallery.addView(strip)
        root.addView(gallery, LinearLayout.LayoutParams(-1, dp(150)))
    }

    private fun addSlider(root: LinearLayout, label: String, key: String, min: Int, max: Int, initial: Int) {
        val title = TextView(this).apply {
            text = "$label: ${prefs.getInt(key, initial)}"
            textSize = 12f; setTextColor(Color.WHITE)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (prefs.getInt(key, initial) - min).coerceIn(0, this.max)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(82, 198, 255))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = p + min; title.text = "$label: $value"
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(title); root.addView(seek)
    }

    private inner class DragTouchListener(
        private val lp: WindowManager.LayoutParams,
        private val onTap: () -> Unit,
        private val windowView: View? = null
    ) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f
        private var startX = 0; private var startY = 0
        private var dragged = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y; dragged = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) dragged = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { wm.updateViewLayout(windowView ?: v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (v === bubble) prefs.edit().putInt("bubble_x", lp.x).putInt("bubble_y", lp.y).apply()
                    if (!dragged) onTap()
                    return true
                }
            }
            return false
        }
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelParams = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object { const val ACTION_CLOSE = "com.oxide.launcher.overlay.CLOSE" }
}
